const aboutData = require("./about");
const storyData = require("./story");
const educationdata = require("./education");

module.exports = {
    about: aboutData,
    story: storyData,
    education: educationdata
};